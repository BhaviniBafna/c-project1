#include <stdio.h>

int main(void) 
{
  int number;
  top:
  printf(" please Enter integer between -100 and +100:");
  scanf("%d",&number);
  /* checking number is within the specified range*/
  if(number<-100 || number>100)
  {
    goto top;
  }
  if(number>=0)
  {
    printf("\n %d is a positive number",number);
  }
  else
  {
    printf("\n %d is a negative number",number);
  }

  /*checking for odd or even*/
  if(number%2==0)
  {
    printf("\n It is an Even number");
  }
  else
  {
    printf("\n It is an Odd number");
  }
  return 0;
}