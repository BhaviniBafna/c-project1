#include <stdio.h>
#include<math.h>
int main() {
  int i1;
  float f1,f2;
  i1=11;
  f1=15.54;
  f2=42.6;
  printf(" %d\n %.0f\n %.0f",i1,floor(f1),floor(f2));
  
  return 0;
}