#include <stdio.h>

int main(void) {
  int a,b,c,d,e;
  printf("enter 5 numbers: ");
  scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
  int largest_5num, smallest_5num;
  /* most difficul one*/
  largest_5num= (a>b?(a>c?(a>d?(a>e?a:e):d>e?d:e):c>d?(c>e?c:e):d>e?d:e):(b>c?(b>d?(b>e?b:e):d>e?d:e):(c>d?(c>e?c:e):d>e?d:e)));

  smallest_5num=(a<b?(a<c?(a<d?(a<e?a:e):d<e?d:e):c<d?(c<e?c:e):d<e?d:e):(b<c?(b<d?(b<e?b:e):d<e?d:e):(c<d?(c<e?c:e):d<e?d:e)));
  
 
  printf("largest of a,b,c,d and e is: %d\n",largest_5num );
  printf("smallest of a,b,c,d and e is: %d\n",smallest_5num );
  return 0;
}
