#include <stdio.h>
struct players {
  char firstname[20];
  char lastname[20];
  float height;
  float weight;
  int position;
  int games_played;
  int point_scored;
  int count;
} p[15];

int main() {
  int i;
  int c;
repeat:
  printf("Enter the player number whose details you want to enter(between 1 to "
         "15):");
  scanf("%d", &i);
  if (i >= 1 && i <= 15) {
    // storing information
    printf("\nFor player %d,", i);
    printf("\nEnter first name: ");
    scanf("%s", p[i].firstname);
    printf("Enter last name: ");
    scanf("%s", p[i].lastname);
    printf("Enter height(in feets): ");
    scanf(" %f", &p[i].height);
    printf("Enter weight(in kgs): ");
    scanf(" %f", &p[i].weight);
    printf("Enter position: ");
    scanf("%d", &p[i].position);
    printf("Games played: ");
    scanf("%d", &p[i].games_played);
    printf("point scored: ");
    scanf("%d", &p[i].point_scored);
    // displaying information
    printf("\n Details of player");
    printf("\nplayer number: %d", i);
    printf("\nFirst name: ");
    puts(p[i].firstname);
    printf("last name: ");
    puts(p[i].lastname);
    printf("Height: %.1f", p[i].height);
    printf("\nweight: %.1f", p[i].weight);
    printf("\nposition: %d", p[i].position);
    printf("\nGames played:%d", p[i].games_played);
    printf("\npoint scored:%d ", p[i].point_scored);
  }
  printf("press 1 to continue/ 0 to exit: ");
  scanf("%d", &c);
  if (c != 0) {
    goto repeat;
  }

  return 0;
}