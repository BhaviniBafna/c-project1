#include <stdio.h>
 
int main()
{
    float celsius, fahrenheit;
    printf("Enter the temperature in Fahrenheit:");
    scanf("%f", &fahrenheit);
    // formula to convert fahrenheit to celsius
    celsius = (fahrenheit - 32) * 5 / 9;
    printf("\n %.2f degree Fahrenheit is equals to %.2f degree Celsius", fahrenheit, celsius);
    return 0;
}