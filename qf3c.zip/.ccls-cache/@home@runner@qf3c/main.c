#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <string.h> 
#include <math.h> 

typedef struct {
    double x;
    double y;
} Point;

typedef struct {
    Point topLeft;   /* top left point of rectangle */
    Point botRight;  /* bottom right point of rectangle */
    Point middle;
    Point new;
} Rectangle;
double height, width, area;
double computeArea(Rectangle *r);
double centr(Rectangle *r );
double mover(Rectangle *r,int,int);

int main()
{
    Point p;
    Rectangle r;
    int x1,y1;
    printf("\nEnter top left point: ");
    scanf("%lf", &r.topLeft.x);
    scanf("%lf", &r.topLeft.y);
    printf("Enter bottom right point: ");
    scanf("%lf", &r.botRight.x);
    scanf("%lf", &r.botRight.y);
    printf("Top left x = %lf  y = %lf\n", r.topLeft.x, r.topLeft.y);
    printf("Bottom right x = %lf  y = %lf\n", r.botRight.x, r.botRight.y);
    printf("Area = %f", computeArea(&r));
    centr(&r);
    printf("\ncenter of Rectangle:\n x = %lf  y = %lf\n", r.middle.x, r.middle.y);
    printf("enter x and y value to shift bottom right point:");
    scanf("%d", & x1);
    scanf("%d", & y1);
    mover(&r,x1,y1);
    printf("\n new point co-ordinates:\n x = %lf  y = %lf\n", r.new.x, r.new.y);
    return 0;
}

double computeArea(Rectangle *r)
{
    height = fabs(fabs(r->topLeft.y) - fabs(r->botRight.y));
    width = fabs(fabs(r->topLeft.x) - fabs(r->botRight.x));
    area = height*width;
    return (area);
}

double centr(Rectangle *r)
{
   r->middle.x=(r ->topLeft.x + width/2);
   r->middle.y=(r ->botRight.y + height/2);
   return 0;
}

double mover(Rectangle *r,int a,int b)
{  
   
   r->new.x=(r ->botRight.x + a );
   r->new.y=(r ->botRight.y + b);
   return 0;
}