#include<stdio.h>        
struct complex          
{
	double real,imag;     //variables holding real and imaginary part of type double
};
int main()
{
	struct complex a1,a2,a3,sum;
	printf("enter the real and imaginary part for first complex number: ");
	scanf("%lf%lf",&a1.real, &a1.imag);
	printf("enter the real and imaginary part for second complex number: ");
	scanf("%lf%lf",&a2.real, &a2.imag);
  printf("\na1= %.2lf%+.2lfi",a1.real,a1.imag);
  printf("\na2= %.2lf%+.2lfi",a2.real,a2.imag);

  sum.real=a1.real+a2.real;     //addition of real part
	sum.imag=a1.imag+a2.imag;     //addition of imaginary part
	printf("\nSum of complex numbers: %.2lf%+.2lfi",sum.real,sum.imag);
	return 0;
}