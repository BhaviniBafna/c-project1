#include <stdio.h>
void swap_num(int*,int*);
int main(void) {
  int a=10,b=500;
  printf("actual numbers\n");
  printf("a=%d b=%d\n",a,b);
  swap_num(&a,&b);
  printf("numbersafter swaping\n");
  printf("a=%d b=%d",a,b);
  
  return 0;
}

void swap_num(int *x,int *y)
{
  int temp;
  temp=*x;
  *x=*y;
  *y=temp;
}