#include <stdio.h>
float calc_larg(float i,float j,float k);
int main(void) {
  float max,a,b,c;
  printf("enter three numbers: ");
  scanf("%f %f %f",&a,&b,&c);
  /*calling function*/
  max=calc_larg(a,b,c);
  return 0;
}

float calc_larg(float i,float j,float k)
{
  float big,mean;
  mean=(i+j+k)/2;
  printf("mean is: %0.2f ",mean);
  big=(i>j?(i>k?i:k):(j>k?j:k));
  printf("largest number is: %0.2f",big);
  return(big);
}