#include<stdio.h> 

int main()
{ 
  char choice;
  float v,r;
  float cal_volume(float);
  
 
  do
  {
    
    printf("\nenter radius of sphere:");
	  scanf("%f",&r);
    v=cal_volume(r); 
	  printf("volume of sphere: %f\n",v);
    printf("want to find volume of sphere:");
    scanf(" %c",&choice);
  }while(choice=='y');
 
}


float cal_volume(float radius)
{ 
  float volume;
  volume=(4*22*radius*radius*radius)/(7*3); 
  return(volume);
  
}