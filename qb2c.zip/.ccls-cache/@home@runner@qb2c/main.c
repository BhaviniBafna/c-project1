#include <stdio.h>

int main(void) 
{
  int a=8812,b=512,c=1200,d=33000;
  int largest_4num, smallest_4num;
  int asc_num[4];
  
  
  largest_4num= (a>b?(a>c?(a>d?a:d):c>d?c:d):(b>c?(b>d?b:d):c>d?c:d));
  asc_num[3]=largest_4num;
  
  smallest_4num= (a<b?(a<c?(a<d?a:d):c<d?c:d):(b<c?(b<d?b:d):c<d?c:d));
  asc_num[0]=smallest_4num;
  /* now we have 1st and the last number lets check for the other two numbers*/
  

printf("variable which holds the maximum value is: %c \n",largest_variable);
printf("maximum value is: %d",largest_4num);
}
