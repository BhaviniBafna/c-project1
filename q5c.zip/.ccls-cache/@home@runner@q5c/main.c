#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  int n,m,count;
  printf("enter the lower limit and upper limit:");
  scanf("%d %d",&n,&m);
  printf("How many random numbers to generate: ");
  scanf("%d",&count);
  
  
  srand(time(0));
  printf("The random numbers are: ");
  for (int i = 0; i < count; i++) 
  {
    int num = (rand() % (m - n + 1)) + n;
    printf("%d ", num);
  }
  return 0;
}