#include <stdio.h>
/* this program will generate reverse of any integer */

int main() {

  int number, reverse = 0, remainder;

  printf("Enter an integer: ");
  scanf("%d", &number);

  while (number != 0) {
    remainder = number % 10;
    reverse = reverse * 10 + remainder;
    number=number/10;
  }

  printf("Reversed number = %d", reverse);

  return 0;
}


