#include <stdio.h>
int pb(int n);
int main(void) {
  int value,num;
  printf("enter positive integer:");
  scanf("%d",&num);
  value=pb(num);
  printf("%d",value);
  return 0;
}

int pb(int n) {
	if (n==0)
		 return 0;
	 else
		 return (n % 2) + 10 * pb(n / 2);
}

