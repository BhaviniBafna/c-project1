#include<stdio.h>
int main() {
  float a=5.1,b=6.33, temp;
  printf("Input  a= %0.2f ; b= %0.2f \n",a,b);
  /*Swapping two numbers using temporary variable */
  temp = a;
  a = b;
  b = temp;
  printf("Output a=%0.2f ; b=%0.2f", a,b);
  return 0; 
}