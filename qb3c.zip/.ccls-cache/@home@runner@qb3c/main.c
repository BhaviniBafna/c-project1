#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  int n,m,rand_num,max_guess=3,guess_num;
  printf("enter the lower limit and upper limit:");
  scanf("%d %d",&n,&m);
  srand(time(0));
  rand_num = (rand() % (m - n + 1)) + n;
  
  printf("\nguess a number: ");
  scanf("%d",&guess_num);
  if (guess_num==rand_num)
  {
    printf("\ncongratulations! you guessed it correct");
    goto bye;
  }
  else
  { if(guess_num>rand_num)
    {
      printf("\nyour guess is high");
    }
    else
    {
      printf("\nguess is low");
    }
    printf("\nguess again: ");
    scanf("%d",&guess_num);
    if (guess_num==rand_num)
    {
      printf("\ncongratulations! you guessed it correct");
      goto bye;
    }
    else
    {
    if(guess_num>rand_num)
      {
        printf("\nyour guess is high");
      }
    else
      {
        printf("guess is low");
      }
    printf("\nthis is your last chance to guess: ");
    scanf("%d",&guess_num);
    if(guess_num==rand_num)
      {
        printf("\ncongratulations! you guessed it correct");
        goto bye;
      }
    
  }
  }
 bye: 
 if(guess_num==rand_num)
 {
   printf("\nyou win");
 }
 else
   printf("\nyou did not guessed it correct,correct number was %d",rand_num);
}