#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  int n=1,m=39,numbers[5],user_num[5],count=0;
  
  srand(time(0));
  for (int i = 0; i < 5; i++) 
  {
    numbers[i] = (rand() % (m - n + 1)) + n;
    printf("enter number: ");
    scanf("%d",& user_num[i]);
   
  }  
  for (int i=0;i<5;i++)
  {
    for(int j=0;j<5;j++)
    {
      if(numbers[i]==user_num[j])
      {
        count+=1;
      }
        
    }
  }
  if(count!=0)
  {
    printf("U Won\n Matched number count: %d",count);
  }
  else
  {
    printf("No match found, random numbers generated are:\n");
    for( int i=0;i<5;i++)
    {
      printf("%d, ",numbers[i]);
    }
  }
}