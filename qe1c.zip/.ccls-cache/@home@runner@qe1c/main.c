#include <stdio.h>
#include <stdlib.h>
int main(void) 
{
 char c_array[10];
 int i_array[10];
 double d_array[10];
 char *c_p;
 int *i_p;
 double *d_p;
  
 c_p = c_array;
 i_p = i_array;
 d_p = d_array;

 printf("Start addresses of arrays c_p=%p, i_p=%p and d_p=%p \n",c_array,i_array,d_array);
for(int count=0; count<5;count++)
  {
    c_p++;
    i_p++;
    d_p++;
  }
 printf("Addresses of 5th elementof each array: c_p=%p, i_p=%p and d_p=%p \n",c_p,i_p,d_p);

  
 getchar(); getchar();
}
