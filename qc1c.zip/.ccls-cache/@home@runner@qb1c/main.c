#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
  int n,m,numbers[20];
  printf("enter the lower limit and upper limit:");
  scanf("%d %d",&n,&m);
  srand(time(0));
  for (int i = 0; i < 20; i++) 
  {
    numbers[i] = (rand() % (m - n + 1)) + n;
  }
  printf("Randomly generate array: \n");
  for (int i = 0; i < 20; i++) 
  {
    printf("%d ",numbers[i]);
  }
  /* assuming first value to be maximum */
  int max = numbers[0];
  int min = numbers[0];

  for(int i=1; i<20; i++)
  {
    if(numbers[i] > max)
    {
      max = numbers[i];
    }
    if(numbers[i] < min)
    {
      min = numbers[i];
    }  
  }
    printf("\nMaximum element = %d\n", max);
    printf("Minimum element = %d", min);

  return 0;
}
