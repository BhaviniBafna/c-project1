#include <stdio.h>

int main(void) {
  int a[] = {5, 15, 34, 54, 14, 2, 52, 72};
  int *p = &a[1], *q = &a[5];
  printf("\n a) *(p+3)=%d",*(p+3));
  printf("\n b) *(q-3)=%d\n",*(q-3));
  printf("\n c) q and p are pointing to the locations that are 4 integers apart");
  printf("\nq-p=%d\n",q-p);
  
  printf("\nd)");
  if(p<q)
  {
    printf("\np=%p",p);
    printf("\nq=%p",q);
    printf("\np<q True\n");
  }
  else
  { 
    printf("p<q false");
  }
  printf("\ne)");
  if(*p<*q)
  { 
    printf("\n*p<*q True");
  }
  else
  {
    printf("\n*p=%d",*p);
    printf("\n*q=%d",*q);
    printf("\n*p<*q false");
  }
  return 0;
}

