#include <stdio.h>
#include <math.h>
 int main(void)
{
  char value;
  int num1,num2;
  int sum,sub,div,remainder,po_wer;
  
  printf("enter any character(+,-,/,%,^): ");
  scanf("%c",&value);
  
  printf("enter 1st number: ");
  scanf("%d",&num1);
  printf("enter 2nd number: ");
  scanf("%d",&num2);

  switch(value)
  {
    case '+':
      sum=num1+num2;
      printf("\n result is: %d",sum);
      break;
    case '-':
      sub=num1-num2;
      printf("\n result is: %d",sub);
      break;
    case '/':
      div=num1/num2;
      printf("\n result is: %d",div);
      break;
    case '%':
      remainder=num1%num2;
      printf("\n result is: %d",remainder);
      break;
    case '^':
      po_wer=pow(num1,num2);
      printf("\n result is: %d",po_wer);
      break;
    default:
      printf("not a valid character");
    
  }
  
}