#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int num,count;
int check_num(int*);

int main()
{
  int n=1,m=10,numbers[50],c;
  printf("enter integer value between 1 & 10: ");
  scanf("%d",&num);
  srand(time(0));
  for (int i = 0; i < 50; i++) 
  {
    numbers[i] = (rand() % (m - n + 1)) + n;
  }
  printf("\n generating 50 random numbers in an array:");
  for(int i=0; i<50; i++)
  {
    c=check_num(&numbers[i]);
  }
  printf("\nchosen number %d apeears %d times in an array of 50 randomly generated numbers",num,c);
  return 0;
}

int check_num(int *n)
{
  printf("%d ",*n);
  if(*n==num)
  {
    count+=1;
  }
  return count;
}