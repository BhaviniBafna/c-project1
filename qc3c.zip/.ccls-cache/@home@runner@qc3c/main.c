#include <math.h>
#include <stdio.h>

int main() {
   int num, numcopy, remainder;
   int result=0;
   printf("Enter positive integer: ");
   scanf("%d", &num);
   numcopy = num;
   while(numcopy!=0)
   {
     remainder=numcopy%10;
     numcopy=numcopy/10;
     result=result+ pow(remainder,3);
   }
   /*if cube of each digit==number, then it is an Armstrong number*/
   if (result == num)
    printf("%d is an Armstrong number.", num);
   else
    printf("%d is not an Armstrong number.\n", num);
  
  /* prime number*/
  int j=2;
  while(j<num-1)
  {
    if(num%j==0)
    {
      printf("\n%d is not a prime number \n",num);
      printf("It is divisible by %d,",j);
      break;
    }
    j++;
  }
  if(j==num)
  {
    printf("%d is a prime number\n",num);
  }

  
   return 0;
}