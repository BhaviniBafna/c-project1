#include <stdio.h>

int main()
{
  int m,n,a[10][10],sum=0;     
  int trans_a[10][10];  
  printf("Enter the number of rows and column: \n");
  scanf("%d %d",&m,&n);   
           
  printf("\nEnter the elements of the matrix: \n");
  for(int i=0;i<m;i++)    
    {
      for(int j=0;j<n;j++)
      {
        scanf("%d",&a[i][j]);
        sum+=a[i][j];
      }
    }
  printf("\n Matrix a (%d x %d) is \n",n,m);
  for(int i=0;i<m;i++)     
    {
     for(int j=0;j<n;j++)
      {
       printf("%d ",a[i][j]);
       trans_a[j][i]=a[i][j]; 
      }
      printf("\n");
    }
    printf("\nTranspose of a matrix a (%d x %d) \n",m,n);
    for(int i=0;i<n;i++)      
    {
      for(int j=0;j<m;j++)
      {
        printf("%d ",trans_a[i][j]);
      }
        printf("\n");
    }
    printf("\nSum of all the elements of matri: %d",sum);
    return 0;
}