#include <stdio.h>
#include <stdlib.h>
void main()
{
    long int numeric_grade;
    printf("Enter your numeric grade: ");
    scanf("%ld",&numeric_grade);

    switch (numeric_grade)
    {
    case 80 ... 100: 
        printf("A grade\n");
        break;
    case 70 ... 79:
        printf("B grade\n");
        break;
    case 60 ... 69:
        printf("C grade\n");
        break;
    case 50 ... 59:
        printf("D grade\n");
        break;
    case 40 ... 49:
        printf("E grade\n");
        break;
    case 0 ... 39:
        printf("F grade\n");
        break;
    default:
        printf(" Error: Invalid input");
        exit(0);
    }
}