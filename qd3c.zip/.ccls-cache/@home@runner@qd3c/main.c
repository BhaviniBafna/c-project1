#include <stdio.h>
int cube_size(int value);
int small_size(int i,int j, int k);
int s1[3],s2[3],s3[3];
int v1,v2,v3;

int main(void) {
  int i=1, count=1,volume,smallest;
  while(count<=3)
  {
    volume=cube_size(i);
    printf("volume is: %d\n",volume);
    count+=1;
    i+=1;
  }
  smallest=small_size(v1,v2,v3);
  if(smallest==1)
  {
    printf("smallest cuboid height,width and length are:");
    printf("%d %d %d",s1[0],s1[1],s1[2]);
  }
  else if(smallest==2)
  {
    printf("smallest cuboid height,width and length are:");
    printf("%d %d %d",s2[0],s2[1],s2[2]);
  }
  else if(smallest==3)
  {
    printf("smallest cuboid height,width and length are:");
    printf("%d %d %d",s3[0],s3[1],s3[2]);
  }
  return 0;
}

int cube_size(int value)
{ 
  if(value==1)
  {
    printf("\nEnter ht,wt,ln: ");
    scanf("%d %d %d",&s1[0],&s1[1],&s1[2]);
    v1=s1[0]*s1[1]*s1[2];
    return(v1);
  }
  if(value==2)
  {
    printf("\nEnter ht,wt,ln: ");
    scanf("%d %d %d",&s2[0],&s2[1],&s2[2]);
    v2=s2[0]*s2[1]*s2[2];
    return(v2);
  }
  if(value==3)
  {
    printf("\nEnter ht,wt,ln: ");
    scanf("%d %d %d",&s3[0],&s3[1],&s3[2]);
    v3=s3[0]*s3[1]*s3[2];
    return(v3);
  }
}

int small_size(int i, int j,int k)
{
  int small;
  small=(i<j?(i<k?1:3):(j<k?2:3));
  return(small);
}