#include <stdio.h>
int main() {
    int student_id;
    printf("Hello world \n");
    printf("enter your id: ");
    scanf("%d",& student_id);
    printf("My student id is: %d",student_id);
    return 0;
}