#include <stdio.h>
int main() {
  int i1;
  float f1,f2;
  i1=11;
  f1=15.54;
  f2=42.6;
  printf("% .0f",f1);
  
  return 0;
}